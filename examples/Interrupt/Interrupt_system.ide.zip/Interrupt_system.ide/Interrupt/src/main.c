/*
 * main.c
 *
 *  Copyright (C) Daniel Kampert, 2018
 *	Website: www.kampis-elektroecke.de
 *  File info: Interrupt example for ZYNQ 7000 SoC.

  GNU GENERAL PUBLIC LICENSE:
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

  Errors and commissions should be reported to DanielKampert@kampis-elektroecke.de
 */

/** @file main.c
 *  @brief Interrupt example for ZYNQ 7000 SoC.

 *  Software for the interrupt example from
 *  https://www.kampis-elektroecke.de/fpga/zynq/interrupts/
 *
 *  @author Daniel Kampert
 */

#include "xgpio.h"
#include "xscugic.h"
#include "xstatus.h"
#include "xparameters.h"
#include "xil_exception.h"

XGpio_Config* GPIO_ConfigPtr;
XGpio Button;
XGpio LED;

XScuGic_Config* GIC_ConfigPtr;
XScuGic GIC;

u32 Status;

static void GpioHandler(void* CallbackRef)
{
	XGpio* GpioPtr = (XGpio*)CallbackRef;

	if(LED.IsReady)
	{
		XGpio_DiscreteWrite(&LED, 1, 0x0A);
		xil_printf("[INFO] Callback\n\r");
	}

	// Clear the interrupt flag
	XGpio_InterruptClear(GpioPtr, XGPIO_IR_CH1_MASK);
}

int main(void)
{
	xil_printf("[INFO] Interrupt example\n\r");

	// Initialize the button core
	GPIO_ConfigPtr = XGpio_LookupConfig(XPAR_BUTTON_DEVICE_ID);
	if(GPIO_ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid button configuration!\n\r");
		return XST_FAILURE;
	}
	Status = XGpio_CfgInitialize(&Button, GPIO_ConfigPtr, GPIO_ConfigPtr->BaseAddress);
	if(Status != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize buttons!\n\r");
		return XST_FAILURE;
	}
	XGpio_InterruptEnable(&Button, XGPIO_IR_CH1_MASK);
	XGpio_InterruptGlobalEnable(&Button);

	// Initialize the LED core
	GPIO_ConfigPtr = XGpio_LookupConfig(XPAR_LED_DEVICE_ID);
	if(GPIO_ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid LED configuration!\n\r");
		return XST_FAILURE;
	}
	Status = XGpio_CfgInitialize(&LED, GPIO_ConfigPtr, GPIO_ConfigPtr->BaseAddress);
	if(Status != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize LED!\n\r");
		return XST_FAILURE;
	}

	// Initialize the GIC
	GIC_ConfigPtr = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
	if(NULL == GIC_ConfigPtr)
	{
		xil_printf("[ERROR] Invalid GIC configuration!\n\r");
		return XST_FAILURE;
	}
	Status = XScuGic_CfgInitialize(&GIC, GIC_ConfigPtr, GIC_ConfigPtr->CpuBaseAddress);
	if(Status != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize GIC!\n\r");
		return XST_FAILURE;
	}

	// Setup the interrupt
	XScuGic_SetPriorityTriggerType(&GIC, XPAR_FABRIC_GPIO_0_VEC_ID, 0xA0, 0x03);
	if(XScuGic_Connect(&GIC, XPAR_FABRIC_GPIO_0_VEC_ID, (Xil_ExceptionHandler)GpioHandler, &Button) != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not connect GpioHandler!\n\r");
		return XST_FAILURE;
	}
	XScuGic_Enable(&GIC, XPAR_FABRIC_GPIO_0_VEC_ID);

	// Enable exceptions
	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XScuGic_InterruptHandler, &GIC);
	Xil_ExceptionEnable();

	while(1)
	{
	}

	return XST_SUCCESS;
}
