/*
 * main.c
 * 
 *  Copyright (C) Daniel Kampert, 2018
 *	Website: www.kampis-elektroecke.de
 *  File info: XADC example for ZYNQ 7000 SoC.

  GNU GENERAL PUBLIC LICENSE:
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

  Errors and commissions should be reported to DanielKampert@kampis-elektroecke.de
 */

/** @file main.c
 *  @brief XADC example for ZYNQ 7000 SoC.

 *  Software for the XADC example from
 *  https://www.kampis-elektroecke.de/fpga/zynq/xadc/
 *
 *  @author Daniel Kampert
 */

#include "stdio.h"
#include "xadcps.h"
#include "xstatus.h"
#include "xparameters.h"

#define XADC_REFERENCE						1.0f

XAdcPs XAdc;
XAdcPs_Config* ConfigPtr;

u32 Status;

int main(void)
{
	u16 RawData;
	float Temperature;
	float Channel14;
	float Channel15;

	xil_printf("[INFO] XADC example\n\r");

	ConfigPtr = XAdcPs_LookupConfig(XPAR_XADCPS_0_DEVICE_ID);
	if(ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid XADC configuration!\n\r");
		return XST_FAILURE;
	}

	Status = XAdcPs_CfgInitialize(&XAdc, ConfigPtr, ConfigPtr->BaseAddress);
	if(Status != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize XADC!\n\r");
		return XST_FAILURE;
	}

	// Set AUX15 in bipolar and AUX14 in unipolar mode
	XAdcPs_SetSequencerMode(&XAdc, XADCPS_SEQ_MODE_SAFE);
	XAdcPs_SetSeqInputMode(&XAdc, XADCPS_SEQ_CH_AUX15);
	XAdcPs_SetSequencerMode(&XAdc, XADCPS_SEQ_MODE_CONTINPASS);

	while(1)
	{
		// Get the on chip temperature
		Temperature = XAdcPs_RawToTemperature(XAdcPs_GetAdcData(&XAdc, XADCPS_CH_TEMP));

		// Get the measurement result for AUX14 and convert into a floating point number
		RawData = XAdcPs_GetAdcData(&XAdc, XADCPS_CH_AUX_MIN + 14);
		Channel14 = RawData * XADC_REFERENCE / 65536.0;

		// Get the measurement result for AUX15 and convert into a floating point number
		// NOTE: This channel is bipolar so you have to check the signed bit
		RawData = XAdcPs_GetAdcData(&XAdc, XADCPS_CH_AUX_MIN + 15);
		if(RawData & 0x8000)
		{
			RawData = (~RawData) + 0x01;
			Channel15 = RawData * -XADC_REFERENCE / 65536.0;
		}
		else
		{
			Channel15 = RawData * XADC_REFERENCE / 65536.0;
		}

		printf("[INFO] XADC results\n\r");
		printf("	Temperature: %f Degree\r\n", Temperature);
		printf("	Channel %d: %f V\r\n", 14, Channel14);
		printf("	Channel %d: %f V\r\n", 15, Channel15);

		for(u32 i = 0x00; i < 0xFFFFFFF; i++) {};
	}

	return XST_SUCCESS;
}
