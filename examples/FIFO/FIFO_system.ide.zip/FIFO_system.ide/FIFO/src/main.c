/*
 * main.c
 *
 *  Copyright (C) Daniel Kampert, 2018
 *	Website: www.kampis-elektroecke.de
 *  File info: AXI_Stream FIFO example for ZYNQ 7000 FPGA.

  GNU GENERAL PUBLIC LICENSE:
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

  Errors and commissions should be reported to DanielKampert@kampis-elektroecke.de
 */

/** @file main.c
 *  @brief AXI-Stream FIFO example for ZYNQ 7000 FPGA.

 *  Software for the FIFO example from
 *  https://www.kampis-elektroecke.de/fpga/zynq/axi-stream-fifo/
 *
 *  @author Daniel Kampert
 */

#include "xllfifo.h"
#include "xstatus.h"
#include "xparameters.h"

#define PACKETS 						64
#define USE_IRQ							1

XLlFifo_Config* Fifo_ConfigPtr;
XLlFifo Fifo;

#if(USE_IRQ)
	#include "xscugic.h"
	#include "xil_exception.h"

	XScuGic_Config* GIC_ConfigPtr;
	XScuGic GIC;
#endif

u32 SourceBuffer[PACKETS];
u32 DestinationBuffer[PACKETS];

#if(USE_IRQ)
	static void FifoHandler(void* CallbackRef)
	{
		XLlFifo* InstancePtr = (XLlFifo*)CallbackRef;

		u32 Pending = XLlFifo_IntPending(InstancePtr);
		while(Pending)
		{
			if(Pending & XLLF_INT_RFPE_MASK)
			{
				xil_printf("	Receive FIFO empty!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_RFPE_MASK);
			}
			else if(Pending & XLLF_INT_RFPF_MASK)
			{
				xil_printf("	Receive FIFO full!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_RFPF_MASK);
			}
			else if(Pending & XLLF_INT_TFPE_MASK)
			{
				xil_printf("	Transmit FIFO empty!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_TFPE_MASK);
			}
			else if(Pending & XLLF_INT_TFPF_MASK)
			{
				xil_printf("	Transmit FIFO full!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_TFPF_MASK);
			}
			else if(Pending & XLLF_INT_RRC_MASK)
			{
				xil_printf("	Receive reset complete!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_RRC_MASK);
			}
			else if(Pending & XLLF_INT_TRC_MASK)
			{
				xil_printf("	Transmit reset complete!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_TRC_MASK);
			}
			else if(Pending & XLLF_INT_RC_MASK)
			{
				xil_printf("	Receive complete!\n\r");

				while(XLlFifo_iRxOccupancy(InstancePtr))
				{
					u32 ReceiveLength = (XLlFifo_iRxGetLen(InstancePtr)) / sizeof(u32);

					for(int i = 0; i < ReceiveLength; i++)
					{
						u32 RxWord = XLlFifo_RxGetWord(InstancePtr);
						DestinationBuffer[i] = RxWord;
						xil_printf("		Data %lu: %lu\n\r", i, RxWord);
					}
				}

				XLlFifo_IntClear(InstancePtr, XLLF_INT_RC_MASK);
			}
			else if(Pending & XLLF_INT_TC_MASK)
			{
				xil_printf("	Transmit complete!\n\r");
				XLlFifo_IntClear(InstancePtr, XLLF_INT_TC_MASK);
			}
			else if(Pending & XLLF_INT_ERROR_MASK)
			{
				xil_printf("	FIFO Error...\n\r");

				if(Pending & XLLF_INT_TSE_MASK)
				{
					xil_printf("		Transmit size error!\n\r");
					XLlFifo_IntClear(InstancePtr, XLLF_INT_TSE_MASK);
				}
				else if(Pending & XLLF_INT_TPOE_MASK)
				{
					xil_printf("		Transmit packet overrun error!\n\r");
					XLlFifo_IntClear(InstancePtr, XLLF_INT_TPOE_MASK);
				}
				else if(Pending & XLLF_INT_RPUE_MASK)
				{
					xil_printf("		Receive packet underrun error!\n\r");
					XLlFifo_IntClear(InstancePtr, XLLF_INT_RPUE_MASK);
				}
				else if(Pending & XLLF_INT_RPORE_MASK)
				{
					xil_printf("		Receive packet overrun read error!\n\r");
					XLlFifo_IntClear(InstancePtr, XLLF_INT_RPORE_MASK);
				}
				else if(Pending & XLLF_INT_RPURE_MASK)
				{
					xil_printf("		Receive packet underrun read error!\n\r");
					XLlFifo_IntClear(InstancePtr, XLLF_INT_RPURE_MASK);
				}

				XLlFifo_IntClear(InstancePtr, XLLF_INT_ERROR_MASK);
			}

			Pending = XLlFifo_IntPending(InstancePtr);
		}
	}
#endif

int main(void)
{
	xil_printf("[INFO] AXI-Stream FIFO example\n\r");

	Fifo_ConfigPtr = XLlFfio_LookupConfig(XPAR_FIFO_DEVICE_ID);
	if(Fifo_ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid FIFO configuration!\r\n");
		return XST_FAILURE;
	}

	if(XLlFifo_CfgInitialize(&Fifo, Fifo_ConfigPtr, Fifo_ConfigPtr->BaseAddress) != XST_SUCCESS)
	{
		xil_printf("[ERROR] FIFO Initialization failed!\n\r");
		return XST_FAILURE;
	}

#if(USE_IRQ)
	GIC_ConfigPtr = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
	if(GIC_ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid GIC configuration!\n\r");
		return XST_FAILURE;
	}
	XScuGic_CfgInitialize(&GIC, GIC_ConfigPtr, GIC_ConfigPtr->CpuBaseAddress);

	// Setup the interrupt
	XScuGic_SetPriorityTriggerType(&GIC, XPAR_FABRIC_LLFIFO_0_VEC_ID, 0xA0, 0x03);
	if(XScuGic_Connect(&GIC, XPAR_FABRIC_LLFIFO_0_VEC_ID, (Xil_ExceptionHandler)FifoHandler, &Fifo) != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not connect GpioHandler!\n\r");
		return XST_FAILURE;
	}
	XScuGic_Enable(&GIC, XPAR_FABRIC_LLFIFO_0_VEC_ID);

	// Enable exceptions
	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XScuGic_InterruptHandler, &GIC);
	Xil_ExceptionEnable();

	// Enable FIFO interrupts
	XLlFifo_IntClear(&Fifo, 0xFFFFFFFF);
	XLlFifo_IntEnable(&Fifo, XLLF_INT_ALL_MASK);
#endif

	// Reset the Tx and the Rx channel
	XLlFifo_TxReset(&Fifo);
	XLlFifo_RxReset(&Fifo);

	xil_printf("[INFO] Start...\n\r");

	// Fill the transmit buffer with data
	xil_printf("[INFO] Generate data!\n\r");
	for(u32 i = 0x00; i < PACKETS; i++)
	{
		SourceBuffer[i] = i * 2;
	}

	// Copy the data bytes from the transmit buffer into the FIFO
	for(u32 i = 0x00; i < PACKETS; i++)
	{
		if(XLlFifo_iTxVacancy(&Fifo))
		{
			XLlFifo_TxPutWord(&Fifo, SourceBuffer[i]);
		}
	}

	// Start the transmission
	XLlFifo_iTxSetLen(&Fifo, PACKETS * sizeof(u32));

#if(!USE_IRQ)
	// Wait for transmission end
	while(!(XLlFifo_IsTxDone(&Fifo)));

	while(XLlFifo_iRxOccupancy(&Fifo))
	{
		u32 ReceiveLength = (XLlFifo_iRxGetLen(&Fifo)) / sizeof(u32);
		for(u32 i = 0x00; i < ReceiveLength; i++)
		{
			u32 RxWord = XLlFifo_RxGetWord(&Fifo);
			DestinationBuffer[i] = RxWord;
			xil_printf("		Data %lu: %lu\n\r", i, RxWord);
		}
	}

	if(!XLlFifo_IsRxDone(&Fifo))
	{
		xil_printf("[ERROR] Failing in receive data!\r\n");
		return XST_FAILURE;
	}

	xil_printf("[INFO] Receive data successful!\r\n");
#endif

	while(1)
	{
	}

	return XST_SUCCESS;
}
