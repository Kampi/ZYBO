/*
 * main.c
 * 
 *  Copyright (C) Daniel Kampert, 2018
 *	Website: www.kampis-elektroecke.de
 *  File info: Processing system and GPIO example for ZYNQ 7000 SoC.

  GNU GENERAL PUBLIC LICENSE:
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

  Errors and commissions should be reported to DanielKampert@kampis-elektroecke.de
 */

/** @file main.c
 *  @brief Processing system and GPIO example for ZYNQ 7000 SoC.

 *  Software for the processing system and GPIO example from
 *  https://www.kampis-elektroecke.de/fpga/zynq/processing-system-und-gpio/
 *
 *  @author Daniel Kampert
 */

#include "xgpio.h"
#include "xil_printf.h"
#include "xparameters.h"

XGpio_Config* ConfigPtr;
XGpio Switches;
XGpio LED;

u32 Data;
u32 Status;

int main(void)
{
	xil_printf("[INFO] Processing System and GPIO example\n\r");

	ConfigPtr = XGpio_LookupConfig(XPAR_GPIO_0_DEVICE_ID);
	if(ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid GPIO switch configuration!\n\r");
		return XST_FAILURE;
	}

	Status = XGpio_CfgInitialize(&Switches, ConfigPtr, ConfigPtr->BaseAddress);
	if(Status != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize switches!\n\r");
		return XST_FAILURE;
	}

	ConfigPtr = XGpio_LookupConfig(XPAR_GPIO_1_DEVICE_ID);
	if(ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid GPIO LED configuration!\n\r");
		return XST_FAILURE;
	}

	Status = XGpio_CfgInitialize(&LED, ConfigPtr, ConfigPtr->BaseAddress);
	if(Status != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize LED!\n\r");
		return XST_FAILURE;
	}

	XGpio_SetDataDirection(&Switches, 1, 0xFFFF);
	XGpio_SetDataDirection(&LED, 1, 0x00);

	while(1)
	{
		Data = XGpio_DiscreteRead(&Switches, 1);
		XGpio_DiscreteWrite(&LED, 1, Data);
	}
	
	return XST_SUCCESS;
}
