/*
 * main.c
 *
 *  Copyright (C) Daniel Kampert, 2020
 *	Website: www.kampis-elektroecke.de
 *  File info: Clocking Wizard dynamic reconfiguration example for ZYNQ 7000 SoC.

  GNU GENERAL PUBLIC LICENSE:
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

  Errors and commissions should be reported to DanielKampert@kampis-elektroecke.de
 */

/** @file main.c
 *  @brief Clocking Wizard dynamic reconfiguration example for ZYNQ 7000 SoC.

 *  Software for the Clocking Wizard example from
 *  https://www.kampis-elektroecke.de/fpga/zynq/clocking-wizard/
 *
 *  @author Daniel Kampert
 */

#include "xgpio.h"
#include "ClockingWizard/ClockingWizard.h"

ClockingWizard_t Device;
ClockingWizard_Clock_t OutputClock;

XGpio_Config* GPIO_ConfigPtr;
XGpio GPIO;

u32 Input = 0x00;
u32 InputOld = 0x00;

int main(void)
{
	xil_printf("[INFO] Clocking Wizard example\n\r");

	GPIO_ConfigPtr = XGpio_LookupConfig(XPAR_GPIO_0_DEVICE_ID);
	if(GPIO_ConfigPtr == NULL)
	{
		xil_printf("[ERROR] Invalid GPIO switch configuration!\n\r");
		return XST_FAILURE;
	}

	if(XGpio_CfgInitialize(&GPIO, GPIO_ConfigPtr, GPIO_ConfigPtr->BaseAddress) != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize switches!\n\r");
		return XST_FAILURE;
	}

	if(ClockingWizard_Init(&Device, XPAR_CLOCKINGWIZARD_BASEADDR) != XST_SUCCESS)
	{
		xil_printf("[ERROR] Can not initialize Clocking Wizard!\n\r");
		return XST_FAILURE;
	}

	ClockingWizard_GetOutput(&Device, &OutputClock);

	xil_printf("[INFO] Clock buffer configuration:\n\r");
	xil_printf("	DIVCLK Divide: %lu\n\r", Device.DIVCLK_DIVIDE);
	xil_printf("	CLKBOUT Mult: %lu\n\r", Device.CLKFBOUT_MULT);
	xil_printf("	CLKBOUT Frac Mult: %lu\n\r", Device.CLKFBOUT_FRAC_Multiply);
	xil_printf("	CLKBOUT Duty: %lu\n\r", Device.CLKFBOUT_PHASE);
	xil_printf("[INFO] Channel configuration:\n\r");
	xil_printf("	Divide: %lu\n\r", OutputClock.DIVIDE);
	xil_printf("	Frac Divide: %lu\n\r", OutputClock.FRAC_Divide);
	xil_printf("	Phase: %lu\n\r", OutputClock.PHASE);
	xil_printf("	Duty: %lu\n\r", OutputClock.DUTY);

	while(1)
	{
		InputOld = Input;

		while(InputOld == Input)
		{
			Input = XGpio_DiscreteRead(&GPIO, 1);
		}

		xil_printf("[INFO] Input selection: %lu\n\r", Input);

		switch(Input)
		{
			case(0):
			{
				xil_printf("[INFO] Set default clock...\n\r");
				ClockingWizard_LoadDefault(&Device);

				break;
			}
			case(1):
			{
				xil_printf("[INFO] Set output clock to 40 MHz...\n\r");
				Device.DIVCLK_DIVIDE = 1;
				Device.CLKFBOUT_MULT = 8;
				Device.CLKFBOUT_FRAC_Multiply = 0;
				OutputClock.DIVIDE = 25;
				OutputClock.FRAC_Divide = 0;
				ClockingWizard_SetClockBuffer(&Device);
				ClockingWizard_SetOutput(&Device, &OutputClock);

				break;
			}
			case(2):
			{
				xil_printf("[INFO] Set output clock to 65 MHz...\n\r");
				Device.DIVCLK_DIVIDE = 1;
				Device.CLKFBOUT_MULT = 8;
				Device.CLKFBOUT_FRAC_Multiply = 125;
				OutputClock.DIVIDE = 15;
				OutputClock.FRAC_Divide = 625;
				ClockingWizard_SetClockBuffer(&Device);
				ClockingWizard_SetOutput(&Device, &OutputClock);

				break;
			}
			case(4):
			{
				xil_printf("[INFO] Set output clock to 108 MHz...\n\r");
				Device.DIVCLK_DIVIDE = 5;
				Device.CLKFBOUT_MULT = 40;
				Device.CLKFBOUT_FRAC_Multiply = 5;
				OutputClock.DIVIDE = 9;
				OutputClock.FRAC_Divide = 375;
				ClockingWizard_SetClockBuffer(&Device);
				ClockingWizard_SetOutput(&Device, &OutputClock);

				break;
			}
			default:
			{
				xil_printf("[ERROR] Invalid selection!\n\r");
				break;
			}
		}

		for(u32 i = 0x00; i < 0xFFFFFFF; i++);
	}

	return XST_SUCCESS;
}
